import { version } from './package.json';

export const VERSION = version;
