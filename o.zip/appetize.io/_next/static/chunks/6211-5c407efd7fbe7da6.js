"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6211],
  {
    38452: function (e, i, h) {
      h.d(i, {
        Z: function () {
          return a;
        },
      });
      var t = h(24246);
      function a(e) {
        return (0, t.jsx)("svg", {
          ...e,
          xmlns: "http://www.w3.org/2000/svg",
          fill: "none",
          viewBox: "0 0 48 48",
          children: (0, t.jsxs)("g", {
            fill: "none",
            children: [
              (0, t.jsx)("path", {
                className: "opacity-25",
                fill: "currentColor",
                d: "M24,48 C10.745166,48 0,37.254834 0,24 C0,10.745166 10.745166,0 24,0 C37.254834,0 48,10.745166 48,24 C48,37.254834 37.254834,48 24,48 Z M24,44 C35.045695,44 44,35.045695 44,24 C44,12.954305 35.045695,4 24,4 C12.954305,4 4,12.954305 4,24 C4,35.045695 12.954305,44 24,44 Z",
              }),
              (0, t.jsx)("path", {
                className: "opacity-75",
                fill: "currentColor",
                d: "M24,0 C37.254834,0 48,10.745166 48,24 L44,24 C44,12.954305 35.045695,4 24,4 L24,0 Z",
              }),
            ],
          }),
        });
      }
    },
    3793: function (e, i, h) {
      h.d(i, {
        Z: function () {
          return a;
        },
      });
      var t = h(70201);
      let a = {
        plans: {
          sponsored: 0,
          basic: 40,
          premium: 400,
          enterprise: 2e3,
          basic_annual: 432,
          premium_annual: 4320,
          enterprise_annual: 21600,
        },
        chromeDevToolsBaseUrl:
          "/chrome_devtools/20200213/inspector/inspector.html",
        devices: t.devices,
      };
    },
    40105: function (e, i, h) {
      h.d(i, {
        DE: function () {
          return s;
        },
        L0: function () {
          return l;
        },
        sY: function () {
          return c;
        },
      });
      var t = h(50657),
        a = h(66428),
        o = h(28898);
      function l() {
        let e = new Date(),
          i =
            e.getFullYear() +
            "-" +
            ("0" + (e.getMonth() + 1)).slice(-2) +
            "-" +
            ("0" + e.getDate()).slice(-2) +
            " " +
            ("0" + e.getHours()).slice(-2) +
            "-" +
            ("0" + e.getMinutes()).slice(-2) +
            "-" +
            ("0" + e.getSeconds()).slice(-2);
        return i;
      }
      function s(e, i, h) {
        return (0, t.format)((0, t.utcToZonedTime)(e, h), i, { timeZone: h });
      }
      function c(e) {
        return (0, a.Z)((0, o.Z)({ start: 0, end: e }));
      }
    },
    70201: function (e) {
      let i = {
        iphone4s: {
          label: "iPhone 4s",
          width: 370,
          height: 733,
          screen: { width: 320, height: 480, top: 125, left: 25 },
          homeButton: { bottom: 35, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone4s_black.png",
            white: "/images/devices/iphone4s_white.png",
          },
        },
        iphone5s: {
          label: "iPhone 5s",
          width: 365,
          height: 782,
          screen: { width: 320, height: 568, top: 105, left: 22 },
          homeButton: { bottom: 20, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone5s_black.png",
            white: "/images/devices/iphone5s_white.png",
          },
        },
        ipodtouch7thgeneration: {
          label: "iPod Touch 7th Gen",
          width: 365,
          height: 782,
          screen: { width: 320, height: 568, top: 105, left: 22 },
          homeButton: { bottom: 20, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/ipodtouch7thgeneration_black.png",
            white: "/images/devices/ipodtouch7thgeneration_white.png",
          },
        },
        iphone6s: {
          label: "iPhone 6s",
          width: 416,
          height: 870,
          screen: { width: 375, height: 668, top: 100, left: 21 },
          homeButton: { bottom: 20, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone6s_black.png",
            white: "/images/devices/iphone6s_white.png",
          },
        },
        iphone6splus: {
          label: "iPhone 6s+",
          width: 460,
          height: 2840 / 3,
          screen: { width: 414, height: 736, top: 320 / 3, left: 70 / 3 },
          homeButton: { bottom: 28, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone6splus_black.png",
            white: "/images/devices/iphone6splus_white.png",
          },
        },
        iphone6: {
          label: "iPhone 6",
          width: 416,
          height: 870,
          screen: { width: 375, height: 668, top: 100, left: 21 },
          homeButton: { bottom: 20, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone6_black.png",
            white: "/images/devices/iphone6_white.png",
          },
        },
        iphone6plus: {
          label: "iPhone 6+",
          width: 460,
          height: 2840 / 3,
          screen: { width: 414, height: 736, top: 320 / 3, left: 70 / 3 },
          homeButton: { bottom: 28, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone6plus_black.png",
            white: "/images/devices/iphone6plus_white.png",
          },
        },
        iphone7: {
          label: "iPhone 7",
          width: 416,
          height: 870,
          screen: { width: 375, height: 668, top: 100, left: 21 },
          homeButton: { bottom: 20, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone7_black.png",
            white: "/images/devices/iphone7_white.png",
          },
        },
        iphone7plus: {
          label: "iPhone 7+",
          width: 460,
          height: 2840 / 3,
          screen: { width: 414, height: 736, top: 320 / 3, left: 70 / 3 },
          homeButton: { bottom: 28, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone7plus_black.png",
            white: "/images/devices/iphone7plus_white.png",
          },
        },
        iphone8: {
          label: "iPhone 8",
          width: 416,
          height: 870,
          screen: { width: 375, height: 668, top: 100, left: 21 },
          homeButton: { bottom: 20, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone8_black.png",
            white: "/images/devices/iphone8_white.png",
          },
        },
        iphone8plus: {
          label: "iPhone 8+",
          width: 460,
          height: 2840 / 3,
          screen: { width: 414, height: 736, top: 320 / 3, left: 70 / 3 },
          homeButton: { bottom: 28, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/iphone8plus_black.png",
            white: "/images/devices/iphone8plus_white.png",
          },
        },
        iphonex: {
          label: "iPhone X",
          width: 409,
          height: 845,
          screen: {
            width: 375,
            height: 812,
            top: 15,
            left: 17,
            borderRadius: 50,
          },
          chrome: {
            black: "/images/devices/iphonex_black.png",
            white: "/images/devices/iphonex_white.png",
          },
        },
        iphonexs: {
          label: "iPhone XS",
          width: 409,
          height: 845,
          screen: {
            width: 375,
            height: 812,
            top: 15,
            left: 17,
            borderRadius: 50,
          },
          chrome: {
            black: "/images/devices/iphonexs_black.png",
            white: "/images/devices/iphonexs_white.png",
          },
        },
        iphonexsmax: {
          label: "iPhone XS Max",
          width: 471,
          height: 948,
          screen: {
            width: 414,
            height: 896,
            top: 26,
            left: 29,
            borderRadius: 50,
          },
          chrome: {
            black: "/images/devices/iphonexsmax_black.png",
            white: "/images/devices/iphonexsmax_white.png",
          },
        },
        iphone11pro: {
          label: "iPhone 11 Pro",
          width: 440,
          height: 860,
          screen: {
            width: 375,
            height: 812,
            top: 24,
            left: 32,
            borderRadius: 40,
          },
          chrome: {
            black: "/images/devices/iphone11pro_black.svg",
            white: "/images/devices/iphone11pro_white.svg",
          },
        },
        iphone11promax: {
          label: "iPhone 11 Pro Max",
          width: 471,
          height: 948,
          screen: {
            width: 414,
            height: 896,
            top: 26,
            left: 29,
            borderRadius: 50,
          },
          chrome: {
            black: "/images/devices/iphone11promax_black.png",
            white: "/images/devices/iphone11promax_white.png",
          },
        },
        iphone12: {
          label: "iPhone 12",
          width: 440,
          height: 884,
          screen: {
            width: 390,
            height: 844,
            top: 19,
            left: 25,
            borderRadius: 46,
          },
          chrome: {
            black: "/images/devices/iphone12_black.svg",
            white: "/images/devices/iphone12_white.svg",
          },
        },
        iphone12mini: {
          label: "iPhone 12 Mini",
          width: 413,
          height: 852,
          screen: {
            width: 375,
            height: 812,
            top: 20,
            left: 18,
            borderRadius: 50,
          },
          chrome: {
            black: "/images/devices/iphone12mini_black.png",
            white: "/images/devices/iphone12mini_white.png",
          },
        },
        iphone12pro: {
          label: "iPhone 12 Pro",
          width: 429,
          height: 884,
          screen: {
            width: 390,
            height: 844,
            top: 19,
            left: 18,
            borderRadius: 50,
          },
          chrome: {
            black: "/images/devices/iphone12pro_black.png",
            white: "/images/devices/iphone12pro_white.png",
          },
        },
        iphone12promax: {
          label: "iPhone 12 Pro Max",
          width: 467,
          height: 966,
          screen: {
            width: 428,
            height: 926,
            top: 19,
            left: 18,
            borderRadius: 50,
          },
          chrome: {
            black: "/images/devices/iphone12promax_black.png",
            white: "/images/devices/iphone12promax_white.png",
          },
        },
        iphone13pro: {
          label: "iPhone 13 Pro",
          width: 440,
          height: 884,
          screen: {
            width: 390,
            height: 844,
            top: 20,
            left: 25,
            borderRadius: 50,
          },
          chrome: {
            black: "/images/devices/iphone13pro_black.svg",
            white: "/images/devices/iphone13pro_white.svg",
          },
        },
        iphone13promax: {
          label: "iPhone 13 Pro Max",
          width: 481,
          height: 971,
          screen: {
            width: 430,
            height: 932,
            top: 20,
            left: 25,
            borderRadius: 52,
          },
          chrome: {
            black: "/images/devices/iphone13promax_black.svg",
            white: "/images/devices/iphone13promax_white.svg",
          },
        },
        iphone14pro: {
          label: "iPhone 14 Pro",
          width: 439,
          height: 892,
          screen: {
            width: 393,
            height: 852,
            top: 19,
            left: 23,
            borderRadius: 54,
          },
          chrome: { black: "/images/devices/iphone14pro_black.svg" },
        },
        iphone14promax: {
          label: "iPhone 14 Pro Max",
          width: 482,
          height: 974,
          screen: {
            width: 430,
            height: 932,
            top: 20,
            left: 26,
            borderRadius: 58,
          },
          chrome: { black: "/images/devices/iphone14pro_black.svg" },
        },
        iphone15pro: {
          label: "iPhone 15 Pro",
          width: 439,
          height: 887,
          screen: {
            width: 393,
            height: 852,
            top: 17,
            left: 23,
            borderRadius: 56,
          },
          chrome: { black: "/images/devices/iphone15pro_black.svg" },
        },
        iphone15promax: {
          label: "iPhone 15 Pro Max",
          width: 482,
          height: 967,
          screen: {
            width: 430,
            height: 932,
            top: 18,
            left: 26,
            borderRadius: 56,
          },
          chrome: { black: "/images/devices/iphone15promax_black.svg" },
        },
        ipadair: {
          label: "iPad Air",
          width: 864,
          height: 1287,
          isTablet: !0,
          screen: { width: 768, height: 1024, top: 130, left: 48 },
          homeButton: { bottom: 30, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/ipadair_black.png",
            white: "/images/devices/ipadair_white.png",
          },
        },
        ipadair2: {
          label: "iPad Air 2",
          width: 864,
          height: 1287,
          isTablet: !0,
          screen: { width: 768, height: 1024, top: 130, left: 48 },
          homeButton: { bottom: 30, width: 60, height: 60 },
          chrome: {
            black: "/images/devices/ipadair2_black.png",
            white: "/images/devices/ipadair2_white.png",
          },
        },
        ipadair4thgeneration: {
          label: "iPad Air",
          width: 924,
          height: 1280,
          isTablet: !0,
          screen: {
            width: 820,
            height: 1180,
            top: 52,
            left: 52,
            borderRadius: 20,
          },
          chrome: {
            black: "/images/devices/ipadair4thgeneration_black.svg",
            white: "/images/devices/ipadair4thgeneration_white.svg",
          },
        },
        ipad9thgeneration: {
          label: "iPad",
          width: 904,
          height: 1290,
          isTablet: !0,
          screen: {
            width: 810,
            height: 1080,
            top: 108,
            left: 46,
            borderRadius: 3,
          },
          homeButton: { bottom: 26, width: 50, height: 50 },
          chrome: {
            black: "/images/devices/ipad9thgeneration_black.svg",
            white: "/images/devices/ipad9thgeneration_white.svg",
          },
        },
        ipadpro97inch: {
          label: 'iPad Pro 9.7"',
          height: 1226,
          width: 852,
          isTablet: !0,
          screen: {
            width: 768,
            height: 1024,
            top: 103,
            left: 42,
            borderRadius: 3,
          },
          homeButton: { bottom: 22, width: 55, height: 55 },
          chrome: { black: "/images/devices/ipadpro97inch_black.svg" },
        },
        ipadpro129inch5thgeneration: {
          label: 'iPad Pro 12.9"',
          width: 1122,
          height: 1464,
          isTablet: !0,
          screen: {
            width: 1024,
            height: 1366,
            top: 48,
            left: 48,
            borderRadius: 20,
          },
          chrome: {
            black: "/images/devices/ipadpro129inch5thgeneration_black.svg",
          },
        },
        ipadmini6thgeneration: {
          label: "iPad Mini",
          width: 874,
          height: 1265,
          isTablet: !0,
          screen: {
            width: 744,
            height: 1133,
            top: 67,
            left: 64,
            borderRadius: 16,
          },
          chrome: { black: "/images/devices/ipadmini6thgeneration_black.svg" },
        },
        nexus5: {
          label: "Nexus 5",
          width: 400,
          height: 795,
          screen: {
            width: 360,
            height: 640,
            top: 67,
            left: 20,
            devicePixelRatio: 3,
          },
          chrome: {
            black: "/images/devices/nexus5_black.png",
            white: "/images/devices/nexus5_white.png",
          },
        },
        nexus7: {
          label: "Nexus 7",
          width: 728,
          height: 1268,
          isTablet: !0,
          screen: {
            width: 600,
            height: 960,
            top: 155,
            left: 64,
            devicePixelRatio: 2,
          },
          chrome: {
            black: "/images/devices/nexus7_black.png",
            white: "/images/devices/nexus7_white.png",
          },
        },
        nexus9: {
          label: "Nexus 9",
          width: 866,
          height: 1288,
          isTablet: !0,
          screen: {
            width: 768,
            height: 1024,
            top: 133,
            left: 49,
            devicePixelRatio: 2,
          },
          chrome: {
            black: "/images/devices/nexus9_black.png",
            white: "/images/devices/nexus9_white.png",
          },
        },
        pixel4: {
          label: "Pixel 4",
          width: 397,
          height: 840,
          screen: {
            width: 360,
            height: 760,
            top: 53,
            left: 15,
            borderRadius: 30,
            devicePixelRatio: 3,
          },
          chrome: { black: "/images/devices/pixel4_black.svg" },
        },
        pixel4xl: {
          label: "Pixel 4 XL",
          width: 531,
          height: 1119,
          screen: {
            width: 480,
            height: 1013,
            top: 70,
            left: 21,
            borderRadius: 42,
            devicePixelRatio: 3,
          },
          chrome: { black: "/images/devices/pixel4_black.svg" },
        },
        d450: {
          label: "d450",
          width: 389,
          height: 829,
          screen: {
            width: 360,
            height: 720,
            top: 46,
            left: 12,
            borderRadius: 16,
            devicePixelRatio: 2,
          },
          chrome: {
            black: "/images/devices/d450_black.png",
            white: "/images/devices/d450_white.png",
          },
        },
        g430: {
          label: "g430",
          width: 728,
          height: 1109,
          screen: {
            width: 600,
            height: 960,
            top: 75,
            left: 64,
            devicePixelRatio: 2,
          },
          chrome: {
            black: "/images/devices/g430_black.png",
            white: "/images/devices/g430_white.png",
          },
        },
        galaxytabs7: {
          label: "Galaxy Tab S7",
          width: 718,
          height: 1099,
          screen: {
            width: 640,
            height: 1024,
            top: 37,
            left: 38,
            devicePixelRatio: 2,
          },
          chrome: {
            black: "/images/devices/galaxytabs7_black.png",
            white: "/images/devices/galaxytabs7_white.png",
          },
        },
        pixel5: {
          label: "Pixel 5",
          width: 1205 / 2.75,
          height: 2456 / 2.75,
          screen: {
            width: 1080 / 2.75,
            height: 2340 / 2.75,
            top: 21,
            left: 21,
            devicePixelRatio: 2.75,
            borderRadius: 96 / 2.75,
          },
          chrome: { black: "/images/devices/pixel5_black.svg" },
        },
        pixel6: {
          width: 404,
          height: 852,
          label: "Pixel 6",
          screen: {
            width: 360,
            height: 800,
            top: 21,
            left: 22,
            borderRadius: 14,
            devicePixelRatio: 3,
          },
          chrome: { black: "/images/devices/pixel6_black.svg" },
        },
        pixel6pro: {
          label: "Pixel 6 Pro",
          width: 508,
          height: 1092,
          screen: {
            width: 480,
            height: 1040,
            top: 21,
            left: 13,
            borderRadius: 22,
            devicePixelRatio: 3,
          },
          chrome: { black: "/images/devices/pixel6pro_black.svg" },
        },
        pixel7: {
          width: 404,
          height: 852,
          label: "Pixel 7",
          screen: {
            width: 360,
            height: 800,
            top: 21,
            left: 22,
            borderRadius: 14,
            devicePixelRatio: 3,
          },
          chrome: { black: "/images/devices/pixel6_black.svg" },
        },
        pixel7pro: {
          label: "Pixel 7 Pro",
          width: 508,
          height: 1092,
          screen: {
            width: 480,
            height: 1040,
            top: 21,
            left: 13,
            borderRadius: 22,
            devicePixelRatio: 3,
          },
          chrome: { black: "/images/devices/pixel6pro_black.svg" },
        },
        arrowsbe: h({
          width: 360,
          height: 640,
          label: "arrows Be",
          devicePixelRatio: 2,
        }),
        basio3: h({
          width: 360,
          height: 640,
          label: "BASIO3",
          devicePixelRatio: 3,
        }),
        galaxys9: h({
          width: 450,
          height: 925,
          label: "Galaxy S9",
          devicePixelRatio: 2,
        }),
        p20lite: h({
          width: 360,
          height: 760,
          label: "P20 lite",
          devicePixelRatio: 2,
        }),
        sense2: h({
          width: 360,
          height: 720,
          label: "AQUOS sense2",
          devicePixelRatio: 2,
        }),
        arrowsbe4plus: h({
          width: 360,
          height: 740,
          label: "arrows Be4 Plus",
          devicePixelRatio: 2,
        }),
        galaxya21: h({
          width: 360,
          height: 800,
          label: "Galaxy A21",
          devicePixelRatio: 2,
        }),
        p40lite5g: h({
          width: 360,
          height: 770,
          label: "P40 lite5G",
          devicePixelRatio: 2,
        }),
        sense5g: h({
          width: 360,
          height: 760,
          label: "AQUOS sense5G",
          devicePixelRatio: 3,
        }),
        xperia10m3: h({
          width: 360,
          height: 840,
          label: "Xperia 10 III",
          devicePixelRatio: 3,
        }),
        galaxys23ultra: h({
          width: 1440 / 2.75,
          height: 3088 / 2.75,
          devicePixelRatio: 2.75,
          label: "Galaxy S23 Ultra",
          isTablet: !0,
        }),
        galaxytabs8ultra: h({
          width: 1232,
          height: 2960 / 1.5,
          devicePixelRatio: 1.5,
          label: "Galaxy Tab S8 Ultra",
          isTablet: !0,
        }),
        stkx3: h({
          width: 720 / 1.75,
          height: 1600 / 1.75,
          devicePixelRatio: 1.75,
          label: "STK X3",
        }),
        lenovotabk10: h({
          width: 800,
          height: 1280,
          devicePixelRatio: 1.5,
          label: "Lenovo Tab K10",
          isTablet: !0,
        }),
      };
      function h(e) {
        return {
          ...e,
          isGeneric: !0,
          isTablet: e.isTablet || !1,
          width: 1.12 * e.width,
          height: 1.12 * e.height,
          screen: {
            width: e.width,
            height: e.height,
            top: 0.05 * e.height,
            left: 0.06 * e.width,
            borderRadius: 1,
            devicePixelRatio: e.devicePixelRatio,
          },
        };
      }
      e.exports = { devices: i };
    },
  },
]);
